"""Datenbankzugriff. Kennt keine Fachmodule."""
